# Disaster Tweet Classification using NLP and Machine Learning

## 1. Project Overview
This project classifies Twitter posts into two categories: **Disaster (1)** and **Non-Disaster (0)**.
It follows the requirements in the supplied project brief: data exploration and preparation, feature engineering,
model selection/training, evaluation/validation, and deployment through a web interface.

## 2. Dataset
The supplied Excel dataset contains **7,613 rows** and the columns:
`id`, `keyword`, `location`, `text`, and `target`.

The supplied file contains 4,342 non-disaster tweets and 3,271 disaster tweets.
Although the brief mentions a 10,000-tweet dataset, this implementation reports the actual supplied dataset size
rather than assuming 10,000 records.

## 3. Data Preparation
The text pipeline:
- converts text to lowercase;
- removes URLs and user mentions;
- removes punctuation/special characters while retaining hashtag symbols;
- normalizes whitespace;
- uses an 80/20 stratified train-test split;
- keeps labels as 0 = non-disaster and 1 = disaster.

## 4. Feature Engineering
TF-IDF features with unigram and bigram representations are used. Sublinear term frequency is enabled.
This captures informative words and short phrases while reducing the impact of very frequent terms.

## 5. Model Selection
Three candidate text classifiers were evaluated on the held-out test set.

| Model | Accuracy | Precision | Recall | F1 |
|---|---:|---:|---:|---:|
| Logistic Regression | 0.8175 | 0.8102 | 0.7508 | 0.7794 |\n| Multinomial Naive Bayes | 0.8214 | 0.8835 | 0.6728 | 0.7639 |\n| Linear SVM | 0.7971 | 0.7725 | 0.7477 | 0.7599 |\n
The final model is **Logistic Regression**. Selection is based primarily on F1-score, with accuracy as a secondary criterion.
The final deployment model is then retrained on all supplied labeled data.

## 6. Validation Results
On the 20% held-out test set, the selected model achieved:
- Accuracy: **0.8175**
- Precision: **0.8102**
- Recall: **0.7508**
- F1-score: **0.7794**
- ROC-AUC: **0.8697**

See `static/confusion_matrix.png`, `static/roc_curve.png`, and `static/pr_curve.png`.

## 7. Deployment
The trained pipeline is serialized as `model/disaster_tweet_model.joblib`.
A Flask web application is provided in `app.py`. It accepts tweet text and returns the predicted class
and confidence score.

## 8. Limitations
- The dataset is labeled and curated; real-time social-media streams may have different language patterns.
- Tweet language can be ambiguous, sarcastic, metaphorical, or context-dependent.
- A prediction should be treated as an automated classification signal, not as confirmation that a disaster is occurring.
- External deployment (for example AWS/Heroku) requires a hosting account and environment configuration.

## 9. Project Structure
- `app.py` - Flask web application
- `train_model.py` - reproducible training/evaluation script
- `model/disaster_tweet_model.joblib` - trained model pipeline
- `templates/index.html` - user interface
- `static/` - CSS and evaluation figures
- `data_twitter_disaster.xlsx` - supplied dataset
- `metrics.json` - measured evaluation results
- `requirements.txt` - Python dependencies
- `README.md` - setup and usage instructions

## 10. Conclusion
The project demonstrates an end-to-end NLP classification workflow for distinguishing disaster-related tweets
from non-disaster tweets, from preprocessing and TF-IDF feature engineering through model comparison,
evaluation, serialization, and a web interface.
