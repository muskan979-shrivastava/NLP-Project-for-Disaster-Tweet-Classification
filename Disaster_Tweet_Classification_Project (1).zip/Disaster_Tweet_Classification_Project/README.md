# Disaster Tweet Classification

An end-to-end NLP machine-learning project that classifies tweets as disaster-related (1) or non-disaster (0).

## Run locally

```bash
pip install -r requirements.txt
python app.py
```

Open the local Flask address shown in the terminal.

## Retrain

```bash
python train_model.py
```

## Included
- Supplied dataset
- Reproducible training script
- Trained model
- Flask deployment
- Evaluation metrics and plots
- Project report
