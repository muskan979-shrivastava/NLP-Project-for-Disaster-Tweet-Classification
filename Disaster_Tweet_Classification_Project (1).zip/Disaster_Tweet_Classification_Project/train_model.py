import re, joblib, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report

DATA_FILE = "data_twitter_disaster.xlsx"
MODEL_FILE = "model/disaster_tweet_model.joblib"

def clean_text(s):
    s = str(s).lower()
    s = re.sub(r"http\S+|www\.\S+", " ", s)
    s = re.sub(r"@\w+", " ", s)
    s = re.sub(r"[^a-z0-9#\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()

df = pd.read_excel(DATA_FILE)
df = df[["text", "target"]].dropna()
df["clean_text"] = df["text"].map(clean_text)

X_train, X_test, y_train, y_test = train_test_split(
    df["clean_text"], df["target"], test_size=0.20,
    random_state=42, stratify=df["target"]
)

model = Pipeline([
    ("tfidf", TfidfVectorizer(
        ngram_range=(1,2), min_df=2, sublinear_tf=True,
        max_features=100000
    )),
    ("classifier", LogisticRegression(max_iter=1500, C=4.0))
])

model.fit(X_train, y_train)
pred = model.predict(X_test)

print("Accuracy :", accuracy_score(y_test, pred))
print("Precision:", precision_score(y_test, pred))
print("Recall   :", recall_score(y_test, pred))
print("F1-score :", f1_score(y_test, pred))
print("\nClassification report:\n", classification_report(y_test, pred))

# Retrain on all labeled data for deployment.
model.fit(df["clean_text"], df["target"])
joblib.dump(model, MODEL_FILE)
print(f"Saved model to {MODEL_FILE}")
