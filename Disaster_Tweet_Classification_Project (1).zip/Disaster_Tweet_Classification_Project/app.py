from flask import Flask, render_template, request
import joblib, re

app = Flask(__name__)
model = joblib.load("model/disaster_tweet_model.joblib")

def clean_text(s):
    s = str(s).lower()
    s = re.sub(r"http\S+|www\.\S+", " ", s)
    s = re.sub(r"@\w+", " ", s)
    s = re.sub(r"[^a-z0-9#\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    confidence = None
    tweet = ""
    if request.method == "POST":
        tweet = request.form.get("tweet", "").strip()
        if tweet:
            cleaned = clean_text(tweet)
            pred = int(model.predict([cleaned])[0])
            if hasattr(model, "predict_proba"):
                confidence = float(max(model.predict_proba([cleaned])[0]) * 100)
            result = "Disaster-related" if pred == 1 else "Non-disaster"
    return render_template("index.html", result=result, confidence=confidence, tweet=tweet)

if __name__ == "__main__":
    app.run(debug=True)
